# Mini Mario Clone

Ein hippiemäßiges Jump'n'Run-Spiel mit Touch-Steuerung, Synth-Musik und Cartoon-Design.